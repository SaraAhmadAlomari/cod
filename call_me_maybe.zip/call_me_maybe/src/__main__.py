"""Command line entry point: natural language prompts to function calls."""

import argparse
import sys

from src.file_handler import (
    load_function_call_tests,
    load_function_definitions,
    save_function_call_results,
)
from src.llm_client import load_model
from src.llm_generator import generate_function_call
from src.models import FunctionCallResult, FunctionCallResults
from src.prompt_builder import build_prompt
from src.tokenizer_utils import prepare_tokenizer


def parse_args() -> argparse.Namespace:
    """Parse command line arguments.

    Returns:
        The parsed arguments.
    """
    parser = argparse.ArgumentParser(
        prog="python -m src",
        description="Translate prompts into function calls using an LLM.",
    )
    parser.add_argument(
        "--functions_definition",
        default="data/input/functions_definition.json",
        help="path to the functions definition file",
    )
    parser.add_argument(
        "--input",
        default="data/input/function_calling_tests.json",
        help="path to the prompts file",
    )
    parser.add_argument(
        "--output",
        default="data/output/function_calling_results.json",
        help="path to the output file",
    )
    return parser.parse_args()


def run(args: argparse.Namespace) -> int:
    """Process every prompt and write the results file.

    Args:
        args: The parsed command line arguments.

    Returns:
        The process exit code.
    """
    try:
        definitions = load_function_definitions(args.functions_definition)
        tests = load_function_call_tests(args.input)
    except ValueError as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1

    if not definitions.root:
        print("Error: no function defined.", file=sys.stderr)
        return 1

    try:
        model = load_model()
        token_bytes = prepare_tokenizer(model)
    except Exception as error:
        print(f"Error: cannot load the model: {error}", file=sys.stderr)
        return 1

    results: list[FunctionCallResult] = []

    for test in tests.root:
        try:
            call = generate_function_call(
                model,
                build_prompt(test.prompt, definitions),
                definitions,
                token_bytes,
            )
        except Exception as error:
            print(
                f"Error: skipping prompt {test.prompt!r}: {error}",
                file=sys.stderr,
            )
            continue

        results.append(
            FunctionCallResult(
                prompt=test.prompt,
                name=call.name,
                parameters=call.parameters,
            )
        )

    try:
        save_function_call_results(
            args.output,
            FunctionCallResults(results),
        )
    except ValueError as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1

    print(f"{len(results)}/{len(tests.root)} results saved to {args.output}")
    return 0


def main() -> None:
    """Run the program."""
    try:
        sys.exit(run(parse_args()))
    except KeyboardInterrupt:
        print("Interrupted.", file=sys.stderr)
        sys.exit(130)


if __name__ == "__main__":
    main()
