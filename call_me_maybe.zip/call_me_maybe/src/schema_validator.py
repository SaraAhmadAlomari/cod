
from typing import Any

from src.models import FunctionDefinitions


def validate_function_call(
    data: dict[str, Any],
    definitions: FunctionDefinitions,
) -> bool:

    if not isinstance(data, dict):
        return False

    if set(data.keys()) != {"name", "parameters"}:
        return False

    function_name = data["name"]
    parameters = data["parameters"]

    if not isinstance(function_name, str):
        return False

    if not isinstance(parameters, dict):
        return False

    function = None
    for item in definitions.root:
        if item.name == function_name:
            function = item
            break

    if function is None:
        return False

    expected_parameters = function.parameters

    if set(parameters.keys()) != set(expected_parameters.keys()):
        return False

    for name, definition in expected_parameters.items():
        value = parameters[name]
        parameter_type = definition.type

        if parameter_type == "string":
            if not isinstance(value, str):
                return False

        elif parameter_type == "number":
            if not isinstance(value, (int, float)) or isinstance(value, bool):
                return False

        elif parameter_type == "integer":
            if not isinstance(value, int) or isinstance(value, bool):
                return False

        elif parameter_type == "boolean":
            if not isinstance(value, bool):
                return False

        else:
            return False

    return True
