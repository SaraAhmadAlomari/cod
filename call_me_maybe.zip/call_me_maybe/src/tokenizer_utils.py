import json
from pathlib import Path
from llm_sdk import Small_LLM_Model


def load_vocab(vocab_path: str) -> dict[str, int]:
    with Path(vocab_path).open("r", encoding="utf-8") as file:
        vocab = json.load(file)

        token_ids = list(vocab.values())

    if len(token_ids) != len(set(token_ids)):
        raise ValueError("Duplicate token IDs found in vocabulary.")

    if not isinstance(vocab, dict):
        raise ValueError("Vocabulary must be a JSON object.")

    for token, token_id in vocab.items():
        if not isinstance(token, str):
            raise ValueError("Vocabulary tokens must be strings.")

        if not isinstance(token_id, int) or isinstance(token_id, bool):
            raise ValueError("Token IDs must be integers.")

    return vocab


def build_byte_decoder() -> dict[str, int]:
    byte_values = (
        list(range(ord("!"), ord("~") + 1))
        + list(range(ord("¡"), ord("¬") + 1))
        + list(range(ord("®"), ord("ÿ") + 1))
    )

    unicode_values = byte_values.copy()
    extra = 0

    for byte in range(256):
        if byte not in byte_values:
            byte_values.append(byte)
            unicode_values.append(256 + extra)
            extra += 1

    return {
        chr(unicode_value): byte
        for byte, unicode_value in zip(
            byte_values,
            unicode_values,
        )
    }


def build_token_bytes(
    vocab: dict[str, int],
) -> dict[int, bytes]:
    byte_decoder = build_byte_decoder()

    token_bytes = {}

    for token, token_id in vocab.items():
        try:
            token_bytes[token_id] = bytes(
                byte_decoder[character]
                for character in token
            )
        except KeyError as error:
            raise ValueError(
                f"Unsupported vocabulary character: {error}"
            )

    return token_bytes


def prepare_tokenizer(
    model: Small_LLM_Model,
) -> dict[int, bytes]:
    vocab_path = model.get_path_to_vocab_file()

    vocab = load_vocab(vocab_path)

    return build_token_bytes(vocab)
