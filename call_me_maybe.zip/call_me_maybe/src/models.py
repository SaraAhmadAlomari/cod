
from typing import Any
from pydantic import BaseModel, RootModel


class ParameterDefinition(BaseModel):
    type: str


class ReturnDefinition(BaseModel):
    type: str


class FunctionDefinition(BaseModel):
    name: str
    description: str
    parameters: dict[str, ParameterDefinition]
    returns: ReturnDefinition


class FunctionDefinitions(RootModel[list[FunctionDefinition]]):
    pass


class FunctionCallTest(BaseModel):
    prompt: str


class FunctionCallTests(RootModel[list[FunctionCallTest]]):
    pass


class FunctionCall(BaseModel):
    name: str
    parameters: dict[str, Any]


class FunctionCallResult(BaseModel):
    prompt: str
    name: str
    parameters: dict[str, Any]


class FunctionCallResults(RootModel[list[FunctionCallResult]]):
    pass
