
import json
from pathlib import Path
from typing import TypeVar

from pydantic import BaseModel, ValidationError

from src.models import (
    FunctionDefinitions,
    FunctionCallTests,
    FunctionCallResults,
)


T = TypeVar("T", bound=BaseModel)


def _load_and_validate(path: str, model: type[T], label: str) -> T:
    file_path = Path(path)

    try:
        with file_path.open("r", encoding="utf-8") as file:
            data = json.load(file)

    except FileNotFoundError:
        raise ValueError(f"{label} file not found: {path}")

    except json.JSONDecodeError as error:
        raise ValueError(
            f"Invalid JSON in {label} file "
            f"at line {error.lineno}, column {error.colno}: "
            f"{error.msg}"
        )

    except UnicodeDecodeError:
        raise ValueError(f"{label} file is not valid UTF-8: {path}")

    except OSError as error:
        raise ValueError(f"Cannot read {label} file: {error}")

    try:
        return model.model_validate(data)

    except ValidationError as error:
        raise ValueError(
            f"Invalid data in {label} file:\n{error}"
        )


def load_function_definitions(path: str) -> FunctionDefinitions:
    return _load_and_validate(
        path,
        FunctionDefinitions,
        "Functions definition",
    )


def load_function_call_tests(path: str) -> FunctionCallTests:
    return _load_and_validate(
        path,
        FunctionCallTests,
        "Function calling tests",
    )


def save_function_call_results(
    path: str,
    results: FunctionCallResults,
) -> None:
    file_path = Path(path)

    try:
        file_path.parent.mkdir(parents=True, exist_ok=True)

        with file_path.open("w", encoding="utf-8") as file:
            json.dump(
                results.model_dump(mode="json"),
                file,
                indent=2,
                ensure_ascii=False,
            )

    except (OSError, TypeError, ValueError) as error:
        raise ValueError(f"Cannot save output file: {error}")
