import json
import numpy as np

from llm_sdk import Small_LLM_Model

from src.models import FunctionCall, FunctionDefinitions
from src.schema_validator import validate_function_call
from src.prefix_validator import (
    is_valid_prefix,
    is_complete_function_call,
)


def get_best_valid_token_id(
    logits: list[float],
    prefix: bytes,
    token_bytes: dict[int, bytes],
    definitions: FunctionDefinitions,
) -> int:

    sorted_token_ids = np.argsort(logits)[::-1]

    for raw_id in sorted_token_ids:
        token_id = int(raw_id)

        if token_id not in token_bytes:
            continue

        candidate = prefix + token_bytes[token_id]

        if is_valid_prefix(candidate, definitions):
            return token_id

    raise ValueError("No valid token found.")


def generate_function_call(
    model: Small_LLM_Model,
    prompt: str,
    definitions: FunctionDefinitions,
    token_bytes: dict[int, bytes],
    max_new_tokens: int = 100,
) -> FunctionCall:

    encoded = model.encode(prompt)
    input_ids = encoded.tolist()[0]

    generated_tokens = []
    prefix = b""

    for _ in range(max_new_tokens):

        logits = model.get_logits_from_input_ids(input_ids)

        next_token_id = get_best_valid_token_id(
            logits,
            prefix,
            token_bytes,
            definitions,
        )

        generated_tokens.append(next_token_id)
        input_ids.append(next_token_id)

        prefix += token_bytes[next_token_id]

        if is_complete_function_call(prefix, definitions):
            generated_text = prefix.decode("utf-8")
            data = json.loads(generated_text)

            if not validate_function_call(data, definitions):
                raise ValueError(
                    "Generated function call does not match its schema."
                )

            return FunctionCall.model_validate(data)

    raise ValueError(
        "Could not generate a complete function call.\n"
        f"Generated text: {prefix!r}"
    )
