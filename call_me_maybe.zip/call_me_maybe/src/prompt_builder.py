
from src.models import FunctionDefinitions


def build_prompt(
    user_prompt: str,
    definitions: FunctionDefinitions,
) -> str:
    functions_description = []

    for function in definitions.root:
        parameters = []

        for name, parameter in function.parameters.items():
            parameters.append(f"{name}: {parameter.type}")

        parameters_text = ", ".join(parameters)

        function_text = (
            f"Name: {function.name}\n"
            f"Description: {function.description}\n"
            f"Parameters: ({parameters_text})\n"
        )

        functions_description.append(function_text)

    available_functions = "\n".join(functions_description)

    return f"""
You are a function calling assistant.

Your task is to select the most appropriate function
for the user's request and extract its parameters.

Available functions:

{available_functions}

User request:
{user_prompt}

Return only a JSON object with this structure:
{{
    "name": "function_name",
    "parameters": {{
        "parameter_name": "parameter_value"
    }}
}}

Do not execute the function.
Do not calculate the result.
Do not include any explanation.
"""
