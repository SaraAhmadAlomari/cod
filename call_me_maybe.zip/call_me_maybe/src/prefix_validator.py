
from src.models import FunctionDefinition, FunctionDefinitions


WHITESPACE = b" \t\n\r"
HEX_DIGITS = b"0123456789abcdefABCDEF"


def skip_whitespace(data: bytes, index: int) -> int:
    while index < len(data) and data[index] in WHITESPACE:
        index += 1

    return index


def is_valid_utf8_prefix(data: bytes) -> bool:
    try:
        data.decode("utf-8")
        return True

    except UnicodeDecodeError as error:
        return (
            error.reason == "unexpected end of data"
            and error.end == len(data)
        )


def read_json_string(
    data: bytes,
    start: int,
) -> tuple[bytes, int, bool, bool]:

    if start >= len(data) or data[start] != ord('"'):
        return b"", start, False, False

    index = start + 1

    while index < len(data):
        character = data[index]

        if character == ord('"'):
            content = data[start + 1:index]

            if not is_valid_utf8_prefix(content):
                return b"", index, False, False

            return content, index + 1, True, True

        if character < 32:
            return b"", index, False, False

        if character == ord("\\"):
            index += 1

            if index >= len(data):
                return b"", index, False, True

            escaped = data[index]

            if escaped in b'"\\/bfnrt':
                index += 1
                continue

            if escaped == ord("u"):
                digits_start = index + 1
                digits_end = digits_start + 4
                digits = data[digits_start:digits_end]

                if len(digits) < 4:
                    if all(char in HEX_DIGITS for char in digits):
                        return b"", len(data), False, True

                    return b"", index, False, False

                if not all(char in HEX_DIGITS for char in digits):
                    return b"", index, False, False

                index = digits_end
                continue

            return b"", index, False, False

        index += 1

    content = data[start + 1:index]

    if not is_valid_utf8_prefix(content):
        return b"", index, False, False

    return content, index, False, True


def expect_character(
    data: bytes,
    index: int,
    expected: int,
) -> tuple[bool, int, bool]:

    index = skip_whitespace(data, index)

    if index == len(data):
        return True, index, False

    if data[index] != expected:
        return False, index, False

    return True, index + 1, True


def expect_string(
    data: bytes,
    index: int,
    expected: str,
) -> tuple[bool, int, bool]:

    index = skip_whitespace(data, index)

    if index == len(data):
        return True, index, False

    if data[index] != ord('"'):
        return False, index, False

    value, next_index, complete, valid = read_json_string(
        data, index
    )

    if not valid:
        return False, next_index, False

    expected_bytes = expected.encode("utf-8")

    if not complete:
        raw_prefix = data[index + 1:]

        if b"\\" in raw_prefix:
            return False, next_index, False

        return expected_bytes.startswith(value), next_index, False

    return value == expected_bytes, next_index, True


def read_json_number(
    data: bytes,
    start: int,
) -> tuple[bytes, int, bool, bool]:

    index = start
    state = "start"

    accepting_states = {
        "zero",
        "integer",
        "fraction",
        "exponent_digits",
    }

    while index < len(data):
        character = data[index]

        if character in WHITESPACE + b",}":
            if state in accepting_states:
                return data[start:index], index, True, True

            return b"", index, False, False

        if state == "start":
            if character == ord("-"):
                state = "sign"
            elif character == ord("0"):
                state = "zero"
            elif character in b"123456789":
                state = "integer"
            else:
                return b"", index, False, False

        elif state == "sign":
            if character == ord("0"):
                state = "zero"
            elif character in b"123456789":
                state = "integer"
            else:
                return b"", index, False, False

        elif state == "zero":
            if character == ord("."):
                state = "decimal"
            elif character in b"eE":
                state = "exponent"
            else:
                return b"", index, False, False

        elif state == "integer":
            if character in b"0123456789":
                pass
            elif character == ord("."):
                state = "decimal"
            elif character in b"eE":
                state = "exponent"
            else:
                return b"", index, False, False

        elif state == "decimal":
            if character in b"0123456789":
                state = "fraction"
            else:
                return b"", index, False, False

        elif state == "fraction":
            if character in b"0123456789":
                pass
            elif character in b"eE":
                state = "exponent"
            else:
                return b"", index, False, False

        elif state == "exponent":
            if character in b"+-":
                state = "exponent_sign"
            elif character in b"0123456789":
                state = "exponent_digits"
            else:
                return b"", index, False, False

        elif state == "exponent_sign":
            if character in b"0123456789":
                state = "exponent_digits"
            else:
                return b"", index, False, False

        elif state == "exponent_digits":
            if character not in b"0123456789":
                return b"", index, False, False

        index += 1

    return (
        data[start:index],
        index,
        state in accepting_states,
        True,
    )


def parse_parameter_value(
    data: bytes,
    index: int,
    parameter_type: str,
) -> tuple[bool, int, bool]:

    index = skip_whitespace(data, index)

    if index == len(data):
        return True, index, False

    if parameter_type == "string":
        _, next_index, complete, valid = read_json_string(
            data, index
        )

        return valid, next_index, complete

    if parameter_type in ("number", "integer"):
        number, next_index, complete, valid = read_json_number(
            data, index
        )

        if not valid:
            return False, next_index, False

        if parameter_type == "integer":
            if any(char in number for char in b".eE"):
                return False, next_index, False

        return True, next_index, complete

    if parameter_type == "boolean":
        remaining = data[index:]

        for literal in (b"true", b"false"):
            if literal.startswith(remaining):
                return True, len(data), False

            if remaining.startswith(literal):
                return True, index + len(literal), True

        return False, index, False

    return False, index, False


def parse_function_prefix(
    data: bytes,
    function: FunctionDefinition,
) -> tuple[bool, bool]:

    index = 0

    valid, index, complete = expect_character(
        data, index, ord("{")
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_string(
        data, index, "name"
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_character(
        data, index, ord(":")
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_string(
        data, index, function.name
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_character(
        data, index, ord(",")
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_string(
        data, index, "parameters"
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_character(
        data, index, ord(":")
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_character(
        data, index, ord("{")
    )
    if not valid or not complete:
        return valid, False

    parameters = list(function.parameters.items())

    if not parameters:
        valid, index, complete = expect_character(
            data, index, ord("}")
        )
        if not valid or not complete:
            return valid, False

        valid, index, complete = expect_character(
            data, index, ord("}")
        )
        if not valid or not complete:
            return valid, False

        index = skip_whitespace(data, index)

        if index < len(data):
            return False, False

        return True, True

    for position, (parameter_name, definition) in enumerate(parameters):
        valid, index, complete = expect_string(
            data, index, parameter_name
        )
        if not valid or not complete:
            return valid, False

        valid, index, complete = expect_character(
            data, index, ord(":")
        )
        if not valid or not complete:
            return valid, False

        valid, index, complete = parse_parameter_value(
            data,
            index,
            definition.type,
        )
        if not valid or not complete:
            return valid, False

        if position < len(parameters) - 1:
            valid, index, complete = expect_character(
                data, index, ord(",")
            )
            if not valid or not complete:
                return valid, False

    valid, index, complete = expect_character(
        data, index, ord("}")
    )
    if not valid or not complete:
        return valid, False

    valid, index, complete = expect_character(
        data, index, ord("}")
    )
    if not valid or not complete:
        return valid, False

    index = skip_whitespace(data, index)

    if index < len(data):
        return False, False

    return True, True


def is_valid_prefix(
    prefix: bytes,
    definitions: FunctionDefinitions,
) -> bool:

    for function in definitions.root:
        valid, _ = parse_function_prefix(prefix, function)

        if valid:
            return True

    return False


def is_complete_function_call(
    data: bytes,
    definitions: FunctionDefinitions,
) -> bool:

    for function in definitions.root:
        valid, complete = parse_function_prefix(
            data,
            function,
        )

        if valid and complete:
            return True

    return False
