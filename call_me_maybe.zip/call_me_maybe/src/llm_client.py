from llm_sdk import Small_LLM_Model


def load_model() -> Small_LLM_Model:
    return Small_LLM_Model()
