*This activity has been created as part of the 42 curriculum by saalomar.*

# call me maybe

## Description

Translates natural language prompts into structured function calls
(`name` + typed `parameters`) using `Qwen/Qwen3-0.6B` and **constrained
decoding**, so the output is always valid JSON matching the schema.

## Instructions

```bash
uv sync
uv run python -m src [--functions_definition FILE] [--input FILE] [--output FILE]
make lint        # flake8 + mypy
```

Defaults: `data/input/functions_definition.json`,
`data/input/function_calling_tests.json`,
`data/output/function_calling_results.json`.

## Example usage

```bash
uv run python -m src
uv run python -m src --input my_prompts.json --output out.json
```

Output: `[{"prompt": "...", "name": "fn_add_numbers", "parameters": {"a": 2, "b": 3}}]`

## Algorithm explanation

1. The prompt (with the function list) is encoded and the model returns the
   logits of the next token.
2. Tokens are sorted by logit. Each one is mapped to its bytes through
   `vocab.json` (GPT-2 byte decoder) and appended to the text generated so far.
3. A hand-written incremental JSON parser (`prefix_validator.py`) checks that
   the result is still a valid prefix of
   `{"name": <function>, "parameters": {<typed args>}}`. The first valid token
   is chosen (equivalent to setting invalid logits to `-inf`).
4. Generation stops as soon as the JSON is complete; the result is checked
   again with `schema_validator.py`.

The function name and the argument values are chosen by the LLM; the
constraint only restricts the structure, keys and value types.

## Design decisions

- Only `numpy`, `pydantic` and `json` are used; no `torch`, `transformers`,
  `outlines`, `dspy`, etc. in `src/` (they are only dependencies of the
  provided `llm_sdk`). No private SDK attribute is used.
- Token-by-token validation on bytes avoids decoding partial UTF-8.
- Errors are reported on stderr; a failing prompt is skipped, never a crash.

## Performance analysis

- Reliability: output is 100% parseable and schema-compliant by construction.
- Accuracy: depends on the 0.6B model's choice of function and values.
- Speed: one forward pass per token; tokens are checked in logit order, so
  the validator is usually called only a few times per step.

## Challenges faced

- Partial tokens (UTF-8 cut in the middle, JSON escapes, numbers): solved
  with a byte-level incremental parser.
- Small model picking weak values: solved with a clear prompt, while the
  structure stays enforced by the decoder.

## Testing strategy

Manual runs with different function sets and prompts, plus edge cases:
empty/invalid/missing JSON files, empty strings, large numbers, special
characters, ambiguous prompts, multi-parameter functions. Lint with
`make lint`.

## Resources

- [Qwen3](https://huggingface.co/Qwen/Qwen3-0.6B)
- [JSON specification](https://www.json.org)
- [Pydantic docs](https://docs.pydantic.dev)

Used of AI to:
1.explain concepts such as llm, tokenization, JSON Schema, and constrained decoding.
2.help design and improve the validation and token-masking logic.
3.suggest improvements in code.

